using System.Xml.Linq;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace MobileStock
{
    public partial class Form1 : Form

    {

            }

            private void btnShowGreeting_Click(object sender, EventArgs e)
            {

                if (string.IsNullOrWhiteSpace(txtName.Text))
                {
                    MessageBox.Show("Please enter item Code.", "Validation Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                lblResult.Text = $"Hello {txtName.Text.Trim()}!";
            }

            public class IteminStore
            {
                public string MobileCode { get; set; }
                public string Make{ get; set; }
                public int Quantity { get; set; }
            }

            private void btnAdd_Click(object sender, EventArgs e)
            {
                if (string.IsNullOrWhiteSpace(txtCode.Text) ||
                    string.IsNullOrWhiteSpace(txtMake.Text) ||
                    string.IsNullOrWhiteSpace(txtQuantity.Text))
                {
                    MessageBox.Show("Please fill in all fields.", "Validation Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(txtMonbileCode.Text,);
                {
                    MessageBox.Show("Item added must be a positive number.", "Input Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                _loans.Add(new IteminStore
                {
                    MobileCode  = txtCode.Text.Trim(),
                    Make = txtMake.Text.Trim(),
                    Quantity = txtQuantity.Text.Trim()
                });

                RefreshGrid();
                txtCode.Clear();
                txtMake.Clear();
                txtQuantity.Clear();
            }

            private void btnDelete_Click(object sender, EventArgs e)
            {
                if (txtQuantity.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Please select a item to delete.", "No Selection",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult confirm = MessageBox.Show("Are you sure you want to delete this item?",
                    "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (confirm == DialogResult.Yes)
                {
                    int index = dgvQuantity.SelectedRows[0].Index;
                    _item.RemoveAt(index);
                    RefreshGrid();
                }
            }

            private void btnClear_Click(object sender, EventArgs e)
            {
                txtCode.Clear();
                txtMake.Clear();
                txtQuanntity.Clear();
           }

            private void RefreshGrid()
            {
                dgvItems.DataSource = null;
                dgvItems.DataSource = _items;
            }
        }
    }

}
