﻿namespace MobileStock
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            moblbl = new Label();
            makelbl = new Label();
            Qlbl = new Label();
            btnAdd = new Button();
            btnDelete = new Button();
            btnFind = new Button();
            txtCode = new TextBox();
            txtMake = new TextBox();
            textQuantity = new TextBox();
            outputlbl = new Label();
            SuspendLayout();
            // 
            // moblbl
            // 
            moblbl.AutoSize = true;
            moblbl.Location = new Point(100, 148);
            moblbl.Name = "moblbl";
            moblbl.Size = new Size(93, 20);
            moblbl.TabIndex = 0;
            moblbl.Text = "Mobile code";
            moblbl.Click += label1_Click;
            // 
            // makelbl
            // 
            makelbl.AutoSize = true;
            makelbl.Location = new Point(99, 188);
            makelbl.Name = "makelbl";
            makelbl.Size = new Size(45, 20);
            makelbl.TabIndex = 1;
            makelbl.Text = "Make";
            makelbl.Click += txtMake_Click;
            // 
            // Qlbl
            // 
            Qlbl.AutoSize = true;
            Qlbl.Location = new Point(99, 222);
            Qlbl.Name = "Qlbl";
            Qlbl.Size = new Size(65, 20);
            Qlbl.TabIndex = 2;
            Qlbl.Text = "Quantity";
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(99, 336);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(94, 29);
            btnAdd.TabIndex = 3;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(209, 336);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(94, 29);
            btnDelete.TabIndex = 4;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += button2_Click;
            // 
            // btnFind
            // 
            btnFind.Location = new Point(332, 336);
            btnFind.Name = "btnFind";
            btnFind.Size = new Size(94, 29);
            btnFind.TabIndex = 5;
            btnFind.Text = "Find";
            btnFind.UseVisualStyleBackColor = true;
            // 
            // txtCode
            // 
            txtCode.Location = new Point(199, 145);
            txtCode.Name = "txtCode";
            txtCode.Size = new Size(125, 27);
            txtCode.TabIndex = 6;
            // 
            // txtMake
            // 
            txtMake.Location = new Point(199, 181);
            txtMake.Name = "txtMake";
            txtMake.Size = new Size(125, 27);
            txtMake.TabIndex = 7;
            // 
            // textQuantity
            // 
            textQuantity.Location = new Point(199, 215);
            textQuantity.Name = "textQuantity";
            textQuantity.Size = new Size(125, 27);
            textQuantity.TabIndex = 8;
            // 
            // outputlbl
            // 
            outputlbl.AutoSize = true;
            outputlbl.Location = new Point(223, 58);
            outputlbl.Name = "outputlbl";
            outputlbl.Size = new Size(0, 20);
            outputlbl.TabIndex = 9;
            outputlbl.Click += label4_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(outputlbl);
            Controls.Add(textQuantity);
            Controls.Add(txtMake);
            Controls.Add(txtCode);
            Controls.Add(btnFind);
            Controls.Add(btnDelete);
            Controls.Add(btnAdd);
            Controls.Add(Qlbl);
            Controls.Add(makelbl);
            Controls.Add(moblbl);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label moblbl;
        private Label makelbl;
        private Label Qlbl;
        private Button btnAdd;
        private Button btnDelete;
        private Button btnFind;
        private TextBox txtCode;
        private TextBox txtMake;
        private TextBox textQuantity;
        private Label outputlbl;
    }
}
